﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public static void Sumar(DataGridView dgva, DataGridView dgvb, DataGridView dgvr)
        {
            dgvr.Rows.Clear();
            for (int x = 0; x < 5; x++)
            {
                dgvr.Rows.Add();
                for (int y = 0; y < 5; y++)
                {
                    dgvr.Rows[x].Cells[y].Value = (Convert.ToDouble(dgva.Rows[x].Cells[y].Value)) + (Convert.ToDouble(dgvb.Rows[x].Cells[y].Value));
                }
            }
            dgvr.ClearSelection();
        }

        public static void Multiplicar(DataGridView dgva, DataGridView dgvb, DataGridView dgvr)
        {
            dgvr.Rows.Clear();
            for (int x = 0; x < 5; x++)
            {
                dgvr.Rows.Add();
                for (int y = 0; y < 5; y++)
                {
                    dgvr.Rows[x].Cells[y].Value = (Convert.ToDouble(dgva.Rows[x].Cells[y].Value)) * (Convert.ToDouble(dgvb.Rows[x].Cells[y].Value));
                }
            }
            dgvr.ClearSelection();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dgvMatriz1.ColumnCount = 5;
            dgvMatriz2.ColumnCount = 5;
            dgvMatriz3.ColumnCount = 5;
            dgvMatriz1.RowHeadersVisible = false;
            dgvMatriz1.ColumnHeadersVisible = false;
            dgvMatriz2.RowHeadersVisible = false;
            dgvMatriz2.ColumnHeadersVisible = false;
            dgvMatriz3.RowHeadersVisible = false;
            dgvMatriz3.ColumnHeadersVisible = false;
            dgvMatriz1.AllowUserToAddRows = false;
            dgvMatriz2.AllowUserToAddRows = false;
            dgvMatriz3.AllowUserToAddRows = false;
            dgvMatriz1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvMatriz2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvMatriz3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            Random r = new Random();
            for (int x = 0 ; x < 5 ; x++)
            {
                dgvMatriz1.Rows.Add();
                for (int y = 0; y < 5; y++)
                {
                    dgvMatriz1.Rows[x].Cells[y].Value = r.Next(10, 91);
                }
            }
            dgvMatriz1.ClearSelection();
            for (int j = 0; j < 5; j++)
            {
                dgvMatriz2.Rows.Add();
                for (int k = 0; k < 5; k++)
                {
                    dgvMatriz2.Rows[j].Cells[k].Value = r.Next(10, 91);
                }
            }
            dgvMatriz2.ClearSelection();

            rbtMultiplicar.Checked = false;
            rbtSumar.Checked = false;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (rbtMultiplicar.Checked == true || rbtSumar.Checked == true)
            {
                if (rbtSumar.Checked == true)
                {
                    Sumar(dgvMatriz1, dgvMatriz2, dgvMatriz3);
                    rbtSumar.Checked = false;
                }
                else
                {
                    Multiplicar(dgvMatriz1, dgvMatriz2, dgvMatriz3);
                    rbtMultiplicar.Checked = false;
                }
            }
            else
            {
                MessageBox.Show("Por favor seleccione una opción para de poder realizar una acción.", "Acción no seleccionada aún", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
