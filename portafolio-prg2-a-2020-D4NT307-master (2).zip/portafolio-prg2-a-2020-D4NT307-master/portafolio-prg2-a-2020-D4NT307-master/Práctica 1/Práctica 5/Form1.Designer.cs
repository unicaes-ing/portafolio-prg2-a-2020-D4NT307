﻿namespace Práctica_5
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstbVendedores = new System.Windows.Forms.ListBox();
            this.btnOrdenarAZ = new System.Windows.Forms.Button();
            this.btnOrdenarZA = new System.Windows.Forms.Button();
            this.btnQuitar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxNombreB = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vendedores";
            // 
            // lstbVendedores
            // 
            this.lstbVendedores.FormattingEnabled = true;
            this.lstbVendedores.Location = new System.Drawing.Point(12, 25);
            this.lstbVendedores.Name = "lstbVendedores";
            this.lstbVendedores.Size = new System.Drawing.Size(128, 186);
            this.lstbVendedores.TabIndex = 1;
            // 
            // btnOrdenarAZ
            // 
            this.btnOrdenarAZ.Location = new System.Drawing.Point(146, 25);
            this.btnOrdenarAZ.Name = "btnOrdenarAZ";
            this.btnOrdenarAZ.Size = new System.Drawing.Size(75, 23);
            this.btnOrdenarAZ.TabIndex = 2;
            this.btnOrdenarAZ.Text = "Ordenar A-Z";
            this.btnOrdenarAZ.UseVisualStyleBackColor = true;
            this.btnOrdenarAZ.Click += new System.EventHandler(this.btnOrdenarAZ_Click);
            // 
            // btnOrdenarZA
            // 
            this.btnOrdenarZA.Location = new System.Drawing.Point(146, 54);
            this.btnOrdenarZA.Name = "btnOrdenarZA";
            this.btnOrdenarZA.Size = new System.Drawing.Size(75, 23);
            this.btnOrdenarZA.TabIndex = 3;
            this.btnOrdenarZA.Text = "Ordenar Z-A";
            this.btnOrdenarZA.UseVisualStyleBackColor = true;
            this.btnOrdenarZA.Click += new System.EventHandler(this.btnOrdenarZA_Click);
            // 
            // btnQuitar
            // 
            this.btnQuitar.Location = new System.Drawing.Point(146, 83);
            this.btnQuitar.Name = "btnQuitar";
            this.btnQuitar.Size = new System.Drawing.Size(75, 23);
            this.btnQuitar.TabIndex = 4;
            this.btnQuitar.Text = "Quitar";
            this.btnQuitar.UseVisualStyleBackColor = true;
            this.btnQuitar.Click += new System.EventHandler(this.btnQuitar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nombre:";
            // 
            // tbxNombreB
            // 
            this.tbxNombreB.Location = new System.Drawing.Point(146, 162);
            this.tbxNombreB.Name = "tbxNombreB";
            this.tbxNombreB.Size = new System.Drawing.Size(75, 20);
            this.tbxNombreB.TabIndex = 6;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(146, 188);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 7;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(235, 225);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.tbxNombreB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnQuitar);
            this.Controls.Add(this.btnOrdenarZA);
            this.Controls.Add(this.btnOrdenarAZ);
            this.Controls.Add(this.lstbVendedores);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Ejer1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstbVendedores;
        private System.Windows.Forms.Button btnOrdenarAZ;
        private System.Windows.Forms.Button btnOrdenarZA;
        private System.Windows.Forms.Button btnQuitar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxNombreB;
        private System.Windows.Forms.Button btnBuscar;
    }
}

