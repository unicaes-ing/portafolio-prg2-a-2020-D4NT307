﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string[][] ventas = new string[5][];

        private void Form3_Load(object sender, EventArgs e)
        {
            ventas[0] = new string[5] { "500", "125", "200", "421.85", "225.30"};
            ventas[1] = new string[2] { "562.85", "175.96"};
            ventas[2] = new string[4] { "850.21", "451.20", "153.30", "98.21"};
            ventas[3] = new string[6] { "521.63", "125.52", "480.22", "189.36", "122.54", "645.23"};
            ventas[4] = new string[4] { "75.22", "150.58", "245.99", "729.99"};
            for (int i = 0; i < ventas.GetLength(0); i++)
            {
                lstSucursales.Items.Add("Sucursal" + (i + 1));
            }
        }

        private void lstSucursales_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstSucursales.SelectedIndex >= 0)
            {
                double total = 0;
                lstVentas.Items.Clear();
                foreach (string venta in ventas[lstSucursales.SelectedIndex])
                {
                    lstVentas.Items.Add(venta);
                    total += Convert.ToDouble(venta);
                }
                lblTotal.Text = total.ToString("C2");
            }
        }
    }
}
