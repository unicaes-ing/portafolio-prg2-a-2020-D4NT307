﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Práctica_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtEjecutar_Click(object sender, EventArgs e)
        {
            
        }

        string[] vendedores = new string[15];

        private void Form1_Load(object sender, EventArgs e)
        {
            vendedores[0] = "Rodrigo Marín";
            vendedores[1] = "Juan Orellana";
            vendedores[2] = "Ernesto Villalta";
            vendedores[3] = "Luis Gálvez";
            vendedores[4] = "Guillermo Arévalo";
            vendedores[5] = "Josué Irión";
            vendedores[6] = "Ricardo Milos";
            vendedores[7] = "James McCloud";
            vendedores[8] = "Alfredo Mercurio";
            vendedores[9] = "El Chus";
            vendedores[10] = "Abigail Mendoza";
            vendedores[11] = "Atreus, hijo de Kratos";
            vendedores[12] = "Kratos";
            vendedores[13] = "Elizabeth Martínez";
            vendedores[14] = "Carlos Jiménez";
            foreach (string vendedor in vendedores)
            {
                lstbVendedores.Items.Add(vendedor);
            }
        }

        private void btnOrdenarAZ_Click(object sender, EventArgs e)
        {
            lstbVendedores.DataSource = null;
            Array.Sort(vendedores);
            lstbVendedores.DataSource = vendedores;
            lstbVendedores.SelectedIndex = -1;
        }

        private void btnOrdenarZA_Click(object sender, EventArgs e)
        {
            lstbVendedores.DataSource = null;
            Array.Sort(vendedores);
            Array.Reverse(vendedores);
            lstbVendedores.DataSource = vendedores;
            lstbVendedores.SelectedIndex = -1;
        }

        private void btnQuitar_Click(object sender, EventArgs e)
        {
            vendedores = vendedores.Where((Item, Index) => Index != lstbVendedores.SelectedIndex).ToArray();
            lstbVendedores.DataSource = null;
            lstbVendedores.DataSource = vendedores;
            lstbVendedores.SelectedIndex = -1;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (tbxNombreB.TextLength >= 0)
            {
                int x = Array.IndexOf(vendedores, tbxNombreB.Text);
                if (x >= 0)
                {
                    lstbVendedores.SelectedIndex = x;
                }
                else
                {
                    MessageBox.Show("El nombre que intenta buscar no se encuentra entre los vendedores.");
                }
            }
        }
    }
}
