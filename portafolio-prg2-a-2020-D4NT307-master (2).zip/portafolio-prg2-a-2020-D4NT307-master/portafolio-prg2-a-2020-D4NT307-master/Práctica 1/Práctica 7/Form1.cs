﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace Práctica_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string nombre;
        string correo;
        string telefono;
        FileStream fs = null;
        BinaryWriter bw = null;
        BinaryReader br = null;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            erp1.Clear();
            string patronNombre = @"^(([A-ZÁÉÍÓÚ][a-zñáéíóú]{2,})(\s)?)*[^\s]$", patronCorreo = @"^[a-z0-9.]{6,}@[a-z]{4,}.com$";
            if (Regex.IsMatch(tbxNombre.Text, patronNombre))
            {
                if (Regex.IsMatch(tbxCorreo.Text, patronCorreo))
                {
                    if (mtxTelefono.MaskFull == true)
                    {
                        try
                        {
                            fs = new FileStream("propietarios.dat", FileMode.Append, FileAccess.Write);
                            bw = new BinaryWriter(fs);
                            nombre = tbxNombre.Text;
                            correo = tbxCorreo.Text;
                            telefono = mtxTelefono.Text;
                            bw.Write(nombre);
                            bw.Write(correo);
                            bw.Write(telefono);
                            MessageBox.Show("Los datos han sido guardados.", "Datos guardados", MessageBoxButtons.OK);
                            tbxNombre.Clear();
                            tbxCorreo.Clear();
                            mtxTelefono.Clear();
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Ha ocurrido un error desconocido.");
                            throw;
                        }
                        finally
                        {
                            if (bw != null) bw.Close();
                        }

                        try
                        {
                            fs = new FileStream("propietarios.dat", FileMode.Open, FileAccess.Read);
                            br = new BinaryReader(fs);
                            dgvPropietario.Rows.Clear();
                            while (true)
                            {
                                nombre = br.ReadString();
                                correo = br.ReadString();
                                telefono = br.ReadString();
                                dgvPropietario.Rows.Add(nombre, correo, telefono);
                            }
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            if (br != null) br.Close();
                            dgvPropietario.ClearSelection();
                        }
                    }
                    else
                    {
                        erp1.SetError(mtxTelefono, "Este campo no puede estar vacío.");
                    }
                }
                else
                {
                    erp1.SetError(tbxCorreo, "Ingrese un formato válido para el correo. (Sin mayúsculas)");
                }
            }
            else
            {
                erp1.SetError(tbxNombre, "Debe ingresar un nombre y un apellido, comenzando cada uno por mayúscula.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 fr2 = new Form2();
            fr2.ShowDialog();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Realmente desea salir del programa?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
                Application.Exit();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                fs = new FileStream("propietarios.dat", FileMode.Open, FileAccess.Read);
                br = new BinaryReader(fs);
                dgvPropietario.Rows.Clear();
                while (true)
                {
                    nombre = br.ReadString();
                    correo = br.ReadString();
                    telefono = br.ReadString();
                    dgvPropietario.Rows.Add(nombre, correo, telefono);
                }
            }
            catch (Exception)
            {
            }
            finally
            {
                if (br != null) br.Close();
                dgvPropietario.ClearSelection();
            }
        }
    }
}
