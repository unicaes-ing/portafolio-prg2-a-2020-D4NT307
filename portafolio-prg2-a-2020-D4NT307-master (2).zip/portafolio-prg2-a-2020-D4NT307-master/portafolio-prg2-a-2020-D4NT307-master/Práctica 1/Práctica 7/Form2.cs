﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Práctica_7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        string nombreprop;
        string correo;
        string tel;
        FileStream fs = null;
        BinaryReader br = null;

        [Serializable]

        public struct Mascota
        {
            public string code;
            public string nombre;
            public string propietario;
            public string especie;
            public string fecha;
            public double peso;
            public string sexo;
        }

        private static Dictionary<string, Mascota> MascotaDictionary = new Dictionary<string, Mascota>();
        private static BinaryFormatter formatter = new BinaryFormatter();
        private const string NOMBRE_ARCHIVO = "mascotas.dat";
        private static void guardarArchivo()
        {
            try
            {
                FileStream writerFS = new FileStream(NOMBRE_ARCHIVO, FileMode.Create, FileAccess.Write);
                formatter.Serialize(writerFS, MascotaDictionary);
                MessageBox.Show("Los datos han sido guardados.");
            }
            catch (Exception)
            {
                Console.WriteLine("No fue posible almacenar los datos de la mascota.");
            }
        }

        private static void leerArchivo()
        {
            if (File.Exists(NOMBRE_ARCHIVO))
            {
                try
                {
                    FileStream readerFS = new FileStream(NOMBRE_ARCHIVO, FileMode.Open, FileAccess.Read);
                    MascotaDictionary = (Dictionary<string, Mascota>)formatter.Deserialize(readerFS);
                    readerFS.Close();
                }
                catch (Exception)
                {
                    Console.WriteLine("El archivo no está dsponible o no fue posible leerlo.");
                }
            }
        }
        public static void actualizarGrid(ref DataGridView grid)
        {
            if (MascotaDictionary.Count > 0)
            {
                grid.Rows.Clear();
                foreach (Mascota mascota in MascotaDictionary.Values)
                {
                    grid.Rows.Add(mascota.code, mascota.nombre, mascota.propietario, mascota.especie, mascota.fecha, mascota.peso, mascota.sexo);
                }
                grid.ClearSelection();
            }
            else
            {
                MessageBox.Show("No existe información almacenada sobre mascotas.");
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string patronCodigo = @"^[A-Z]{2}[0-9]{4}$", patronNombre = @"^(([A-ZÁÉÍÓÚ][a-zñáéíóú]{2,})(\s)?)*[^\s]$";
            if (Regex.IsMatch(tbxCodMascota.Text, patronCodigo))
            {
                if (Regex.IsMatch(tbxNombre.Text, patronNombre))
                {
                    if (cbxPropietario.Text.Length >= 0)
                    {
                        if (cbxEspecie.Text.Length >= 0)
                        {
                            if (double.TryParse(tbxPeso.Text, out double peso))
                            {
                                if (rbtHembra.Checked || rbtMacho.Checked)
                                {
                                    try
                                    {
                                        Mascota mascota = new Mascota();
                                        mascota.code = tbxCodMascota.Text;
                                        mascota.nombre = tbxNombre.Text;
                                        mascota.propietario = cbxPropietario.Text;
                                        mascota.especie = cbxEspecie.Text;
                                        mascota.fecha = dtpFecha.Text;
                                        mascota.peso = Convert.ToDouble(tbxPeso.Text);
                                        if (rbtHembra.Checked == true)
                                        {
                                            mascota.sexo = "Hembra";
                                        }
                                        else if (rbtMacho.Checked == true)
                                        {
                                            mascota.sexo = "Macho";
                                        }
                                        if (MascotaDictionary.ContainsKey(mascota.code))
                                        {
                                            MessageBox.Show("Ya fue agregado el código antes una mascota con el código " + mascota.code);
                                        }
                                        else
                                        {
                                            MascotaDictionary.Add(mascota.code, mascota);
                                            guardarArchivo();
                                            leerArchivo();
                                            actualizarGrid(ref dgvMascotas);
                                            tbxCodMascota.Clear();
                                            tbxNombre.Clear();
                                            cbxPropietario.Text = "";
                                            cbxEspecie.Text = "";
                                            tbxPeso.Clear();
                                            rbtHembra.Checked = false;
                                            rbtMacho.Checked = false;
                                            tbxCodMascota.Focus();
                                        }
                                    }
                                    catch (Exception)
                                    {
                                        MessageBox.Show("Ingrese los datos correctamente");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            leerArchivo();
            actualizarGrid(ref dgvMascotas);
            cbxEspecie.Text = "";
            cbxPropietario.Text = "";
            try
            {
                fs = new FileStream("propietarios.dat", FileMode.Open, FileAccess.Read);
                br = new BinaryReader(fs);
                cbxPropietario.Items.Clear();
                while (true)
                {
                    nombreprop = br.ReadString();
                    correo = br.ReadString();
                    tel = br.ReadString();
                    cbxPropietario.Items.Add(nombreprop);
                }
            }
            catch(Exception)
            {
            }
            finally
            {
                if (br != null) br.Close();
                dgvMascotas.ClearSelection();
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Realmente desea salir del programa?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
                Application.Exit();
            }
        }
    }
}
