﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int fibonacci = 0;
            if (int.TryParse(tbxNum.Text, out int numF))
            {
                fibonacci = Funciones.Fibonacci(numF);
            }
            else
            {
                MessageBox.Show("Por favor asegúrese de ingresar un número entero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
