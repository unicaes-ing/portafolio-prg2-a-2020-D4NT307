﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btSumar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(tbxNum1.Text, out double n1) && double.TryParse(tbxNum2.Text, out double n2) && double.TryParse(tbxNum3.Text, out double n3) && double.TryParse(tbxNum4.Text, out double n4))
            {
                double total = Funciones.Suma(n1, n2, n3, n4);
                label6.Text = Convert.ToString(total);
            }
            else
            {
                MessageBox.Show("Por favor ingrese números reales válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
