﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_4
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void btMayor_Click(object sender, EventArgs e)
        {
            string resultado = "";
            if (tbxN3.Text == "")
            {
                if (tbxN1.Text != "" && tbxN2.Text != "")
                {
                    if (int.TryParse(tbxN1.Text, out int num1) && int.TryParse(tbxN2.Text, out int num2))
                    {
                        resultado = Funciones.Mayor(num1, num2);
                    }
                    else
                    {
                        MessageBox.Show("Debe asegurarse de que los datos ingresados sean números enteros.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Al menos dos campos deben estar llenos para poder llevar a cabo la operación.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (tbxN1.Text != "" && tbxN2.Text != "")
                {
                    if (int.TryParse(tbxN1.Text, out int num1) && int.TryParse(tbxN2.Text, out int num2) && int.TryParse(tbxN3.Text, out int num3))
                    {
                        resultado = Funciones.Mayor(num1, num2, num3);
                    }
                    else
                    {
                        MessageBox.Show("Debe asegurarse de que los datos ingresados sean números enteros.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            lblMayor.Text = resultado;
        }
    }
}
