﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        

        private void btAgregar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(tbxNum.Text, out int num))
            {
                lstbNumsL.Items.Add(num);
            }
            else
            {
                MessageBox.Show("Debe ingresar un número entero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                int numb = Convert.ToInt32(tbxBuscar.Text), cant = 0;
                cant = Funciones.Buscar(numb, lstbNumsL);
                MessageBox.Show("El número " + numb + " se encuentra: " + cant + " veces.", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("Debe asegurarse de que el número ingresado sea un entero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }
    }
}
