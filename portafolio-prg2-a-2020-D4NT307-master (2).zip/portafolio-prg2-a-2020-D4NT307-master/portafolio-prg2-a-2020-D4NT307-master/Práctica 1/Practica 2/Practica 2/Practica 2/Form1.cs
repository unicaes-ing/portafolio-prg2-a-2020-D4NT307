﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numacon;
            numacon = Convert.ToInt32(textBox1.Text);
            if (numacon > 0 && numacon < 11)
            {
                switch (numacon)
                {
                    case 1:
                        label3.Text = "I";
                        break;
                    case 2:
                        label3.Text = "II";
                        break;
                    case 3:
                        label3.Text = "III";
                        break;
                    case 4:
                        label3.Text = "IV";
                        break;
                    case 5:
                        label3.Text = "V";
                        break;
                    case 6:
                        label3.Text = "VI";
                        break;
                    case 7:
                        label3.Text = "VII";
                        break;
                    case 8:
                        label3.Text = "VIII";
                        break;
                    case 9:
                        label3.Text = "IX";
                        break;
                    case 10:
                        label3.Text = "X";
                        break;
                }
            }
            else
            {
                MessageBox.Show("La cantidad elegida debe estar entre 1 y 10", "Numero invalido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
