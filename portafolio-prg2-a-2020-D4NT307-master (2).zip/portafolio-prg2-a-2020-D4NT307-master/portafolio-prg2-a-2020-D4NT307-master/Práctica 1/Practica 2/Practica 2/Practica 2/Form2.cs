﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
            int cantidad;
            double precio, subtotal, desc = 0, total = 0;
            cantidad = Convert.ToInt32(TxtbCant.Text);
            precio = Convert.ToDouble(TxtbPrec.Text);
            subtotal = cantidad * precio;
            if (radioButton1.Checked == true)
            {
                desc = 0;
                total = subtotal;
            }
            else if (radioButton2.Checked == true)
            {
                desc = subtotal * 0.05;
                total = subtotal - desc;
            }
            else if (radioButton3.Checked == true)
            {
                desc = subtotal * 0.1;
                total = subtotal - desc;
            }
            else if (radioButton4.Checked == true)
            {
                desc = subtotal * 0.15;
                total = subtotal - desc;
            }
            else if (radioButton5.Checked == true)
            {
                desc = subtotal * 0.2;
                total = subtotal - desc;
            }
            TxtbDesc.Text = String.Format("{0:C2}", desc);
            TxtbTotal.Text = String.Format("{0:C2}", total);
        }

        private void BtLimpiar_Click(object sender, EventArgs e)
        {
            TxtbCant.Text = "";
            TxtbPrec.Text = "";
            TxtbDesc.Text = "";
            TxtbTotal.Text = "";
        }

        private void BtSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
