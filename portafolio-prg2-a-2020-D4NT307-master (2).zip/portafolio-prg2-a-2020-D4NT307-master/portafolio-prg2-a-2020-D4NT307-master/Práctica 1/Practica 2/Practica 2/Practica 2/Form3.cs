﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void BtConvertir_Click(object sender, EventArgs e)
        {
            double cant = Convert.ToDouble(TxbLongitud.Text), total = 0;
            string long1 = listBox1.Text, long2 = listBox2.Text;
            if (long1 == "Pulgadas")
            {

                switch (long2)
                {
                    case "Pulgadas":
                        total = cant * 1;
                        break;
                    case "Pies":
                        total = cant * 0.0833333;
                        break;
                    case "Yardas":
                        total = cant * 0.0277778;
                        break;
                    default:
                        break;
                }
            }
            else if (long1 == "Pies")
            {
                switch (long2)
                {
                    case "Pulgadas":
                        total = cant * 12;
                        break;
                    case "Pies":
                        total = cant * 1;
                        break;
                    case "Yardas":
                        total = cant * 0.333333;
                        break;
                    default:
                        break;
                }
            }
            else if (long1 == "Yardas")
            {
                switch (long2)
                {
                    case "Pulgadas":
                        total = cant * 36;
                        break;
                    case "Pies":
                        total = cant * 3;
                        break;
                    case "Yardas":
                        total = cant * 1;
                        break;
                    default:
                        break;
                }
            }
            TxBTotal.Text = total.ToString();
        }

        private void BtSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
