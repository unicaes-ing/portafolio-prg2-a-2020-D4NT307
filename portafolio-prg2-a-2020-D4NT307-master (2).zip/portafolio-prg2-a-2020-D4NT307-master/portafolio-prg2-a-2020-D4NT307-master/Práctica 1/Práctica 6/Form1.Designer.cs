﻿namespace Práctica_6
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstEmpleados = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtLimpiar = new System.Windows.Forms.RadioButton();
            this.rbtOrdenar = new System.Windows.Forms.RadioButton();
            this.rbtQuitar = new System.Windows.Forms.RadioButton();
            this.rbtInsertar = new System.Windows.Forms.RadioButton();
            this.rbtBuscar = new System.Windows.Forms.RadioButton();
            this.rbtAgregar = new System.Windows.Forms.RadioButton();
            this.btEjecutar = new System.Windows.Forms.Button();
            this.btSalir = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Empleado:";
            // 
            // lstEmpleados
            // 
            this.lstEmpleados.FormattingEnabled = true;
            this.lstEmpleados.Location = new System.Drawing.Point(12, 61);
            this.lstEmpleados.Name = "lstEmpleados";
            this.lstEmpleados.Size = new System.Drawing.Size(128, 173);
            this.lstEmpleados.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(128, 20);
            this.textBox1.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtLimpiar);
            this.groupBox1.Controls.Add(this.rbtOrdenar);
            this.groupBox1.Controls.Add(this.rbtQuitar);
            this.groupBox1.Controls.Add(this.rbtInsertar);
            this.groupBox1.Controls.Add(this.rbtBuscar);
            this.groupBox1.Controls.Add(this.rbtAgregar);
            this.groupBox1.Location = new System.Drawing.Point(146, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox1.Size = new System.Drawing.Size(103, 164);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Acción";
            // 
            // rbtLimpiar
            // 
            this.rbtLimpiar.AutoSize = true;
            this.rbtLimpiar.Location = new System.Drawing.Point(7, 135);
            this.rbtLimpiar.Name = "rbtLimpiar";
            this.rbtLimpiar.Size = new System.Drawing.Size(58, 17);
            this.rbtLimpiar.TabIndex = 5;
            this.rbtLimpiar.TabStop = true;
            this.rbtLimpiar.Text = "Limpiar";
            this.rbtLimpiar.UseVisualStyleBackColor = true;
            // 
            // rbtOrdenar
            // 
            this.rbtOrdenar.AutoSize = true;
            this.rbtOrdenar.Location = new System.Drawing.Point(7, 112);
            this.rbtOrdenar.Name = "rbtOrdenar";
            this.rbtOrdenar.Size = new System.Drawing.Size(63, 17);
            this.rbtOrdenar.TabIndex = 4;
            this.rbtOrdenar.TabStop = true;
            this.rbtOrdenar.Text = "Ordenar";
            this.rbtOrdenar.UseVisualStyleBackColor = true;
            // 
            // rbtQuitar
            // 
            this.rbtQuitar.AutoSize = true;
            this.rbtQuitar.Location = new System.Drawing.Point(7, 89);
            this.rbtQuitar.Name = "rbtQuitar";
            this.rbtQuitar.Size = new System.Drawing.Size(53, 17);
            this.rbtQuitar.TabIndex = 3;
            this.rbtQuitar.TabStop = true;
            this.rbtQuitar.Text = "Quitar";
            this.rbtQuitar.UseVisualStyleBackColor = true;
            // 
            // rbtInsertar
            // 
            this.rbtInsertar.AutoSize = true;
            this.rbtInsertar.Location = new System.Drawing.Point(7, 66);
            this.rbtInsertar.Name = "rbtInsertar";
            this.rbtInsertar.Size = new System.Drawing.Size(60, 17);
            this.rbtInsertar.TabIndex = 2;
            this.rbtInsertar.TabStop = true;
            this.rbtInsertar.Text = "Insertar";
            this.rbtInsertar.UseVisualStyleBackColor = true;
            // 
            // rbtBuscar
            // 
            this.rbtBuscar.AutoSize = true;
            this.rbtBuscar.Location = new System.Drawing.Point(7, 43);
            this.rbtBuscar.Name = "rbtBuscar";
            this.rbtBuscar.Size = new System.Drawing.Size(58, 17);
            this.rbtBuscar.TabIndex = 1;
            this.rbtBuscar.TabStop = true;
            this.rbtBuscar.Text = "Buscar";
            this.rbtBuscar.UseVisualStyleBackColor = true;
            // 
            // rbtAgregar
            // 
            this.rbtAgregar.AutoSize = true;
            this.rbtAgregar.Location = new System.Drawing.Point(7, 20);
            this.rbtAgregar.Name = "rbtAgregar";
            this.rbtAgregar.Size = new System.Drawing.Size(62, 17);
            this.rbtAgregar.TabIndex = 0;
            this.rbtAgregar.TabStop = true;
            this.rbtAgregar.Text = "Agregar";
            this.rbtAgregar.UseVisualStyleBackColor = true;
            // 
            // btEjecutar
            // 
            this.btEjecutar.Location = new System.Drawing.Point(146, 182);
            this.btEjecutar.Name = "btEjecutar";
            this.btEjecutar.Size = new System.Drawing.Size(75, 23);
            this.btEjecutar.TabIndex = 4;
            this.btEjecutar.Text = "Ejecutar";
            this.btEjecutar.UseVisualStyleBackColor = true;
            this.btEjecutar.Click += new System.EventHandler(this.btEjecutar_Click);
            // 
            // btSalir
            // 
            this.btSalir.Location = new System.Drawing.Point(175, 254);
            this.btSalir.Name = "btSalir";
            this.btSalir.Size = new System.Drawing.Size(75, 23);
            this.btSalir.TabIndex = 5;
            this.btSalir.Text = "Salir";
            this.btSalir.UseVisualStyleBackColor = true;
            this.btSalir.Click += new System.EventHandler(this.btSalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 289);
            this.Controls.Add(this.btSalir);
            this.Controls.Add(this.btEjecutar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lstEmpleados);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Ejer1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstEmpleados;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtLimpiar;
        private System.Windows.Forms.RadioButton rbtOrdenar;
        private System.Windows.Forms.RadioButton rbtQuitar;
        private System.Windows.Forms.RadioButton rbtInsertar;
        private System.Windows.Forms.RadioButton rbtBuscar;
        private System.Windows.Forms.RadioButton rbtAgregar;
        private System.Windows.Forms.Button btEjecutar;
        private System.Windows.Forms.Button btSalir;
    }
}

