﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Realmente desea salir del programa?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private static void LlenarLista(DataGridView dgv, Dictionary<string, string> dnry)
        {
            dgv.Rows.Clear();
            foreach (KeyValuePair<string, string> nomtel2 in dnry)
            {
                dgv.Rows.Add(nomtel2.Key, nomtel2.Value);
            }
        }

        Dictionary<string, string> telNom = new Dictionary<string, string>();

        private void btAgregar_Click(object sender, EventArgs e)
        {
            string patronNombre = @"^(([A-ZÁÉÍÓÚ][a-zñáéíóú]{2,})(\s)?)*[^\s]$";
            errorProvider1.Clear();
            bool valid1 = true, valid2 = true;
            if (mtxTelefono.MaskFull)
            {
                if (tbxNombre.Text.Length > 0)
                {
                    if (Regex.IsMatch(tbxNombre.Text, patronNombre))
                    {
                        foreach (KeyValuePair<string, string> valid in telNom)
                        {
                            if (mtxTelefono.Text == valid.Key)
                            {
                                valid1 = false;
                            }
                            else
                            {
                                if (tbxNombre.Text == valid.Value)
                                {
                                    valid2 = false;
                                }
                            }
                        }
                        if (!valid1)
                        {
                            MessageBox.Show("El teléfono ingresado ya existe en la lista.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            if (!valid2)
                            {
                                MessageBox.Show("El nombre que ha ingresado ya se encuentra dentro de la lista.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                telNom.Add(mtxTelefono.Text, tbxNombre.Text);
                                LlenarLista(dgvTelNom, telNom);
                                mtxTelefono.Clear();
                                tbxNombre.Clear();
                                mtxTelefono.Focus();
                            }
                        }
                    }
                    else
                    {
                        errorProvider1.SetError(tbxNombre, "Debe ingresar un nombre valido (Formato: Nombre Apellido");
                    }
                }
                else
                {
                    errorProvider1.SetError(tbxNombre, "Este campo es obligatorio para poder seguir con la operación.");
                }
            }
            else
            {
                errorProvider1.SetError(mtxTelefono, "Debe ingresar un número de teléfono completo.");
            }
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            mtxTelefono.Focus();
            errorProvider2.SetError(btBuscar, "Solo es necesario el número de teléfono para la búsqueda.");
        }

        private void btBuscar_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            if (mtxTelefono.MaskFull)
            {
                foreach (DataGridViewRow row in dgvTelNom.Rows)
                {
                    String x = row.Index.ToString();
                    string value = Convert.ToString(row.Cells[0].Value), tel = mtxTelefono.Text;
                    if (value == tel)
                    {
                        dgvTelNom.Rows[Convert.ToInt32(x)].DefaultCellStyle.BackColor = Color.DarkOrange;
                    }
                    else
                    {
                        dgvTelNom.Rows[Convert.ToInt32(x)].DefaultCellStyle.BackColor = Color.White;
                    }
                }
            }
            else
            {
                errorProvider1.SetError(mtxTelefono, "Debe ingresar un número de teléfono completo.");
            }
            mtxTelefono.Clear();
            tbxNombre.Clear();
            mtxTelefono.Focus();
        }

        private void btQuitar_Click(object sender, EventArgs e)
        {
            string key = dgvTelNom.CurrentRow.Cells[0].Value.ToString();
            telNom.Remove(key);
            LlenarLista(dgvTelNom, telNom);
        }
    }
}
