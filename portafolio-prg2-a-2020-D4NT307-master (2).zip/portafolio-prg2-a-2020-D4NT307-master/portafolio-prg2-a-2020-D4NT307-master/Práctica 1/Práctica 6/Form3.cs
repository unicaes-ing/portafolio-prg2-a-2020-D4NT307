﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            mtxNIT.Focus();
            erp1.Clear();
        }

        Dictionary<string, string> sueldoNombre = new Dictionary<string, string>();

       
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            erp1.Clear();
            bool doesntexist = true;
            string patronNombre = @"^(([A-ZÁËÏÖÜ][a-zñáéíóú]{2,})(\s)?)*[^\s]$";
            if (mtxNIT.MaskFull == true)
            {
                if (tbxNombre.Text.Length > 0)
                {
                    if (Regex.IsMatch(tbxNombre.Text, patronNombre))
                    {
                        if (double.TryParse(tbxSueldo.Text, out double sueldo))
                        {
                            foreach (KeyValuePair<string, string> valid in sueldoNombre)
                            {
                                if (mtxNIT.Text == valid.Key)
                                {
                                    doesntexist = false;
                                }
                            }
                            if (!doesntexist)
                            {
                                MessageBox.Show("El NIT que intenta ingresar ya se encuentra registrado, intente con otro.", "NIT ya registrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                mtxNIT.Clear();
                                mtxNIT.Focus();
                            }
                            else
                            {
                                sueldoNombre.Add(mtxNIT.Text, tbxNombre.Text);
                                double totalsueldo = 0;
                                dgvPlanilla.Rows.Add(mtxNIT.Text, tbxNombre.Text, tbxSueldo.Text);
                                for (int x = 0; x < dgvPlanilla.Rows.Count; x++)
                                {
                                    totalsueldo += Convert.ToDouble(dgvPlanilla.Rows[x].Cells[2].Value);
                                }
                                lblTotal.Text = totalsueldo.ToString("C2");
                                tbxNombre.Clear();
                                tbxSueldo.Clear();
                                mtxNIT.Clear();
                                mtxNIT.Focus();
                            }
                            
                        }
                        else
                        {
                            tbxSueldo.Clear();
                            erp1.SetError(tbxSueldo, "Debe ser un número real positivo.");
                        }
                    }
                    else
                    {
                        tbxNombre.Clear();
                        erp1.SetError(tbxNombre, "Solo se puede ingresar un nombre y un apellido comenzando por mayúsculas.");
                    }
                }
                else
                {
                    tbxNombre.Clear();
                    erp1.SetError(tbxNombre, "Este campo no puede estar vacío.");
                }
            }
            else
            {
                mtxNIT.Clear();
                erp1.SetError(mtxNIT, "Este campo no puede estar vacío.");
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (mtxNITB.MaskFull == true)
            {
                foreach (DataGridViewRow row in dgvPlanilla.Rows)
                {
                    String x = row.Index.ToString();
                    string value = Convert.ToString(row.Cells[0].Value), nitb = mtxNITB.Text;
                    if (value == nitb)
                    {
                        dgvPlanilla.Rows[Convert.ToInt32(x)].DefaultCellStyle.BackColor = Color.Yellow;
                    }
                    else
                    {
                        dgvPlanilla.Rows[Convert.ToInt32(x)].DefaultCellStyle.BackColor = Color.White;
                    }
                }
            }
            else
            {
                erp1.SetError(mtxNITB, "Este campo no puede estar vacío.");
            }
            mtxNITB.Clear();
            mtxNIT.Focus();
        }

        private void btnQuitar_Click(object sender, EventArgs e)
        {
            if (mtxNITB.MaskFull == true)
            {
                foreach (DataGridViewRow row in dgvPlanilla.Rows)
                {
                    String x = row.Index.ToString();
                    string value = Convert.ToString(row.Cells[0].Value), nitb = mtxNITB.Text;
                    if (value == nitb)
                    {
                        sueldoNombre.Remove(nitb);
                        dgvPlanilla.Rows.RemoveAt(dgvPlanilla.Rows[Convert.ToInt32(x)].Index);
                    }
                }
            }
            else
            {
                erp1.SetError(mtxNITB, "Este campo no puede estar vacío.");
            }
            mtxNITB.Clear();
            mtxNIT.Focus();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Realmente desea salir del programa?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
