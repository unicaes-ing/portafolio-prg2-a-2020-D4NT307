﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Práctica_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private static ArrayList empleados = new ArrayList();
        
        public static void LlenarLista(ListBox lista)
        {
            lista.Items.Clear();
            foreach (string empleado in empleados)
            {
                lista.Items.Add(empleado);
            }
        }

        private void BuscaAlWey(string buscado)
        {
            if(!string.IsNullOrEmpty(buscado))
            {
                int index = lstEmpleados.FindString(buscado);
                if (index != -1)
                {
                    lstEmpleados.SetSelected(index, true);
                }
                else
                {
                    MessageBox.Show("No se pudo encontrar a la persona que busca.", "No econtrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btEjecutar_Click(object sender, EventArgs e)
        {
            if (rbtAgregar.Checked == true || rbtBuscar.Checked == true || rbtInsertar.Checked == true || rbtLimpiar.Checked == true || rbtOrdenar.Checked == true || rbtQuitar.Checked == true)
            {
                if (rbtAgregar.Checked == true)
                {
                    if (textBox1.Text != String.Empty)
                    {
                        empleados.Add(textBox1.Text);
                        LlenarLista(lstEmpleados);
                        textBox1.Clear();
                        textBox1.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Debe ingresar un nombre para poder ingresar a la lista de empleados.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (rbtBuscar.Checked == true)
                {
                    if (textBox1.Text != String.Empty)
                    {
                        BuscaAlWey(textBox1.Text);
                    }
                    else
                    {
                        MessageBox.Show("Debe ingresar un nombre para poder buscar a la lista de empleados.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (rbtInsertar.Checked == true)
                {
                    if (textBox1.Text != String.Empty)
                    {
                        if (lstEmpleados.SelectedIndex != -1)
                        {
                            lstEmpleados.Items.Insert(lstEmpleados.SelectedIndex, textBox1.Text);
                            empleados.Insert((lstEmpleados.SelectedIndex)-1, textBox1.Text);
                            textBox1.Clear();
                            textBox1.Focus();
                            LlenarLista(lstEmpleados);
                        }
                        else
                        {
                            MessageBox.Show("Seleccione la posición en la que quiere ingresar al nuevo empleado en la lista.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Debe ingresar un nombre para poder insertar a la lista de empleados.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (rbtQuitar.Checked == true)
                {
                    if (lstEmpleados.SelectedIndex >= 0)
                    {
                        lstEmpleados.Items.Remove(lstEmpleados.SelectedIndex);
                        empleados.RemoveAt(lstEmpleados.SelectedIndex);
                        LlenarLista(lstEmpleados);
                    }
                }
                else if (rbtOrdenar.Checked == true)
                {
                    if (lstEmpleados.Items.Count > 1)
                    {
                        empleados.Sort();
                        LlenarLista(lstEmpleados);
                    }
                }
                else if (rbtLimpiar.Checked == true)
                {
                    if (MessageBox.Show("¿Realmente desea limpiar la lista de empleados actual? No se podrá recuperar nunca (Mucho tiempo).", "Limpiar lista", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
                    lstEmpleados.Items.Clear();
                    empleados.Clear();
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar una de las acciones posibles para poder realizar una de las operaciones.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            empleados.Add("Juan");
            empleados.Add("Ana");
            empleados.Add("José");
            empleados.Add("Mario");
            empleados.Add("Julio");
            empleados.Add("Iris");
            LlenarLista(lstEmpleados);
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Realmente desea salir del programa?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
