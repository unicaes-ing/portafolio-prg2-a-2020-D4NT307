﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void tbxNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void btAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = tbxNombre.Text.ToString();
                double horas = Convert.ToDouble(tbxHoras.Text), valorh = Convert.ToDouble(tbxValorH.Text), subtotal = horas * valorh, impuestos = subtotal * 0.1, total = subtotal - impuestos, totalPlanilla = 0;
                int x = dataGridView1.Rows.Add();
                dataGridView1.Rows[x].Cells[0].Value = tbxNombre.Text;
                dataGridView1.Rows[x].Cells[1].Value = tbxHoras.Text;
                dataGridView1.Rows[x].Cells[2].Value = tbxValorH.Text;
                dataGridView1.Rows[x].Cells[3].Value = subtotal;
                dataGridView1.Rows[x].Cells[4].Value = impuestos;
                dataGridView1.Rows[x].Cells[5].Value = total;
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    totalPlanilla += Convert.ToDouble(dataGridView1.Rows[i].Cells[5].Value);
                }

                lblTotalPlanilla.Text = "$" + totalPlanilla.ToString();

            }
            catch (Exception)
            {
                MessageBox.Show("Ha ocurrido un error al procesar los datos, asegúrese de que estos sean correctos, y que todos los campos estén llenos para poder proceder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            
        }

        private void btLimpiar_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }
    }
}
