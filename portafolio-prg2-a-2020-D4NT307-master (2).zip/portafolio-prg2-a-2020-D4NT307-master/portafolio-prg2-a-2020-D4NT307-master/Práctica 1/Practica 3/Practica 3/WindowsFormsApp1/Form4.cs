﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dataGridView1.Size = new Size(210, 220);
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ScrollBars = ScrollBars.None;
            dataGridView1.ColumnCount = 10;
            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Rows.Add();
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = r.Next(10, 100);
                }
            }
            dataGridView1.ClearSelection();
        }

        private void btBuscar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(tbNumBuscar.Text, out int numBuscar))
            {
                if (numBuscar >= 10 && numBuscar <= 99)
                {
                    int found = 0;
                    for (int x = 0; x < 10; x++)
                    {
                        for (int y = 0; y < 10; y++)
                        {
                            if (numBuscar == Convert.ToInt32(dataGridView1.Rows[y].Cells[x].Value))
                            {
                                dataGridView1.Rows[y].Cells[x].Style.BackColor = Color.Yellow;
                                found++;
                            }
                            else
                            {
                                dataGridView1.Rows[y].Cells[x].Style.BackColor = Color.White;
                            }
                        }
                    }
                    if (found == 0)
                    {
                        MessageBox.Show("No se ha encontrado el número que ha intentado buscar.", "Número no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Debe ingresar un número que se encuentre entre 10 y 99", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor ingrese un número entero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
