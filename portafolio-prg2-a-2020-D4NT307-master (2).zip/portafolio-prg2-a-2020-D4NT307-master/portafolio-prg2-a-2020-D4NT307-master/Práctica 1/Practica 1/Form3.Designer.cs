﻿namespace Practica_1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxInver1 = new System.Windows.Forms.TextBox();
            this.tbxInver2 = new System.Windows.Forms.TextBox();
            this.tbxInver3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbxPorcentaje1 = new System.Windows.Forms.TextBox();
            this.tbxPorcentaje2 = new System.Windows.Forms.TextBox();
            this.tbxPorcentaje3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxTotal = new System.Windows.Forms.TextBox();
            this.btCalcular = new System.Windows.Forms.Button();
            this.btLimpiar = new System.Windows.Forms.Button();
            this.btSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Inversionistas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "1.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "2.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "3.";
            // 
            // tbxInver1
            // 
            this.tbxInver1.Location = new System.Drawing.Point(39, 34);
            this.tbxInver1.Name = "tbxInver1";
            this.tbxInver1.Size = new System.Drawing.Size(100, 20);
            this.tbxInver1.TabIndex = 4;
            // 
            // tbxInver2
            // 
            this.tbxInver2.Location = new System.Drawing.Point(39, 61);
            this.tbxInver2.Name = "tbxInver2";
            this.tbxInver2.Size = new System.Drawing.Size(100, 20);
            this.tbxInver2.TabIndex = 5;
            // 
            // tbxInver3
            // 
            this.tbxInver3.Location = new System.Drawing.Point(39, 88);
            this.tbxInver3.Name = "tbxInver3";
            this.tbxInver3.Size = new System.Drawing.Size(100, 20);
            this.tbxInver3.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(216, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Porcentajes";
            // 
            // tbxPorcentaje1
            // 
            this.tbxPorcentaje1.Enabled = false;
            this.tbxPorcentaje1.Location = new System.Drawing.Point(199, 34);
            this.tbxPorcentaje1.Name = "tbxPorcentaje1";
            this.tbxPorcentaje1.Size = new System.Drawing.Size(100, 20);
            this.tbxPorcentaje1.TabIndex = 8;
            // 
            // tbxPorcentaje2
            // 
            this.tbxPorcentaje2.Enabled = false;
            this.tbxPorcentaje2.Location = new System.Drawing.Point(199, 61);
            this.tbxPorcentaje2.Name = "tbxPorcentaje2";
            this.tbxPorcentaje2.Size = new System.Drawing.Size(100, 20);
            this.tbxPorcentaje2.TabIndex = 9;
            // 
            // tbxPorcentaje3
            // 
            this.tbxPorcentaje3.Enabled = false;
            this.tbxPorcentaje3.Location = new System.Drawing.Point(199, 88);
            this.tbxPorcentaje3.Name = "tbxPorcentaje3";
            this.tbxPorcentaje3.Size = new System.Drawing.Size(100, 20);
            this.tbxPorcentaje3.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Total de inversión:";
            // 
            // tbxTotal
            // 
            this.tbxTotal.Enabled = false;
            this.tbxTotal.Location = new System.Drawing.Point(39, 151);
            this.tbxTotal.Name = "tbxTotal";
            this.tbxTotal.Size = new System.Drawing.Size(100, 20);
            this.tbxTotal.TabIndex = 12;
            // 
            // btCalcular
            // 
            this.btCalcular.Location = new System.Drawing.Point(26, 186);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(75, 23);
            this.btCalcular.TabIndex = 13;
            this.btCalcular.Text = "Calcular";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.btCalcular_Click);
            // 
            // btLimpiar
            // 
            this.btLimpiar.Location = new System.Drawing.Point(131, 186);
            this.btLimpiar.Name = "btLimpiar";
            this.btLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btLimpiar.TabIndex = 14;
            this.btLimpiar.Text = "Limpiar";
            this.btLimpiar.UseVisualStyleBackColor = true;
            this.btLimpiar.Click += new System.EventHandler(this.btLimpiar_Click);
            // 
            // btSalir
            // 
            this.btSalir.Location = new System.Drawing.Point(236, 186);
            this.btSalir.Name = "btSalir";
            this.btSalir.Size = new System.Drawing.Size(75, 23);
            this.btSalir.TabIndex = 15;
            this.btSalir.Text = "Salir";
            this.btSalir.UseVisualStyleBackColor = true;
            this.btSalir.Click += new System.EventHandler(this.btSalir_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 229);
            this.Controls.Add(this.btSalir);
            this.Controls.Add(this.btLimpiar);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.tbxTotal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbxPorcentaje3);
            this.Controls.Add(this.tbxPorcentaje2);
            this.Controls.Add(this.tbxPorcentaje1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbxInver3);
            this.Controls.Add(this.tbxInver2);
            this.Controls.Add(this.tbxInver1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Inversiones";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxInver1;
        private System.Windows.Forms.TextBox tbxInver2;
        private System.Windows.Forms.TextBox tbxInver3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbxPorcentaje1;
        private System.Windows.Forms.TextBox tbxPorcentaje2;
        private System.Windows.Forms.TextBox tbxPorcentaje3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbxTotal;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.Button btLimpiar;
        private System.Windows.Forms.Button btSalir;
    }
}